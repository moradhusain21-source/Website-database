.method public english_font(Landroid/view/View;)V
    .registers 10

    # কন্টেক্সট নির্ধারণ
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;
    move-result-object v0

    # ডায়ালগ ইনিশিয়ালাইজেশন
    new-instance v1, Landroid/app/Dialog;
    invoke-direct {v1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    # লেআউট ইনফ্লেট ও সেট করা
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;
    move-result-object v2
    const v3, 0x7f0a007c
    const/4 v4, 0x0
    invoke-virtual {v2, v3, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;
    move-result-object v2
    invoke-virtual {v1, v2}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    # ওয়েবভিউ খুঁজে বের করা
    const v3, 0x7f08029a
    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    move-result-object v3
    check-cast v3, Landroid/webkit/WebView;
    if-nez v3, :cond_35
    return-void

    :cond_35
    # ওয়েবভিউ সেটিংস এনাবল করা
    const/4 v4, 0x1
    const/4 v5, 0x0
    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v5
    invoke-virtual {v5, v4}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    # হ্যান্ডলার এবং ক্লায়েন্ট সেটআপ
    new-instance v5, Lcom/imaginstudio/imagetools/pixellab/WebViewBackHandler;
    invoke-direct {v5, v3}, Lcom/imaginstudio/imagetools/pixellab/WebViewBackHandler;-><init>(Landroid/webkit/WebView;)V
    invoke-virtual {v1, v5}, Landroid/app/Dialog;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)V
    new-instance v5, Lcom/imaginstudio/imagetools/pixellab/FontDownloadHandler;
    const-string v6, "English"
    invoke-direct {v5, v0, v6}, Lcom/imaginstudio/imagetools/pixellab/FontDownloadHandler;-><init>(Landroid/content/Context;Ljava/lang/String;)V
    invoke-virtual {v3, v5}, Landroid/webkit/WebView;->setDownloadListener(Landroid/webkit/DownloadListener;)V

    # ইউআরএল লোড এবং উইন্ডো সাইজ নির্ধারণ
    const-string v5, "https://www.google.com/search?q=dafont"
    invoke-virtual {v3, v5}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;
    move-result-object v5
    const/4 v6, -0x1
    invoke-virtual {v5, v6, v6}, Landroid/view/Window;->setLayout(II)V
    
    # ডায়ালগ প্রদর্শন
    invoke-virtual {v1}, Landroid/app/Dialog;->show()V
    return-void
.end method
