.method public bangla_font(Landroid/view/View;)V
    .registers 10

    # কন্টেক্সট নির্ধারণ
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;
    move-result-object v0

    # ডায়ালগ ইনিশিয়ালাইজেশন
    new-instance v1, Landroid/app/Dialog;
    invoke-direct {v1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    # ডায়ালগ উইন্ডো কনফিগারেশন
    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;
    move-result-object v2
    const/4 v3, 0x1
    invoke-virtual {v2, v3}, Landroid/view/Window;->requestFeature(I)Z

    # ডায়ালগ ব্যাকগ্রাউন্ড ট্রান্সপারেন্ট করা
    new-instance v4, Landroid/graphics/drawable/ColorDrawable;
    const/4 v5, 0x0
    invoke-direct {v4, v5}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V
    invoke-virtual {v2, v4}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    # লেআউট ফাইল ইনফ্লেট করা
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;
    move-result-object v2
    const v3, 0x7f0a007c
    const/4 v4, 0x0
    invoke-virtual {v2, v3, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;
    move-result-object v2
    invoke-virtual {v1, v2}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    # ওয়েবভিউ খুঁজে বের করা
    const v3, 0x7f08029a
    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    move-result-object v3
    check-cast v3, Landroid/webkit/WebView;
    if-nez v3, :cond_35
    return-void

    :cond_35
    # জাভাস্ক্রিপ্ট এবং ওয়েবভিউ সেটিংস সেটআপ
    const/4 v4, 0x1
    const/4 v5, 0x0
    invoke-virtual {v3, v4, v5}, Landroid/webkit/WebView;->setLayerType(ILandroid/graphics/Paint;)V
    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v5
    invoke-virtual {v5, v4}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V
    invoke-virtual {v5, v4}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    # ব্যাক বাটন এবং ডাউনলোড হ্যান্ডলার যুক্ত করা
    new-instance v5, Lcom/imaginstudio/imagetools/pixellab/WebViewBackHandler;
    invoke-direct {v5, v3}, Lcom/imaginstudio/imagetools/pixellab/WebViewBackHandler;-><init>(Landroid/webkit/WebView;)V
    invoke-virtual {v1, v5}, Landroid/app/Dialog;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)V
    new-instance v5, Lcom/imaginstudio/imagetools/pixellab/FontDownloadHandler;
    const-string v6, "English"
    invoke-direct {v5, v0, v6}, Lcom/imaginstudio/imagetools/pixellab/FontDownloadHandler;-><init>(Landroid/content/Context;Ljava/lang/String;)V
    invoke-virtual {v3, v5}, Landroid/webkit/WebView;->setDownloadListener(Landroid/webkit/DownloadListener;)V

    # ইউআরএল লোড করা এবং ডায়ালগ দেখানো
    const-string v5, "https://www.google.com/search?q=dafont"
    invoke-virtual {v3, v5}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    invoke-virtual {v1}, Landroid/app/Dialog;->show()V
    return-void
.end method
